import json

def process_files():
    """
    Process JSONL files and generate statistics
    """
    # File names as you mentioned
    files = {
        'World Knowledge': 'world knowledge.jsonl',
        'Science': 'Science Felm.jsonl', 
        'Mathematics': 'Math domain.jsonl',
        'Reasoning': 'Reasoning.jsonl'
    }
    
    results = {}
    
    for domain_name, filename in files.items():
        try:
            total_prompts = 0
            total_segments = 0
            
            print(f"Processing {filename}...")
            
            with open(filename, 'r', encoding='utf-8') as f:
                for line in f:
                    try:
                        data = json.loads(line.strip())
                        total_prompts += 1
                        # Count segments from factual_label list
                        factual_label = data.get('factual_label', [])
                        total_segments += len(factual_label)
                    except json.JSONDecodeError:
                        print(f"  Warning: Could not parse JSON line in {filename}")
                        continue
            
            avg_segments = round(total_segments / total_prompts, 2) if total_prompts > 0 else 0
            
            results[domain_name] = {
                'prompts': total_prompts,
                'segments': total_segments,
                'avg_segments': avg_segments
            }
            
            print(f"  Found: {total_prompts} prompts, {total_segments} segments")
            
        except FileNotFoundError:
            print(f"Error: File {filename} not found in current directory")
            results[domain_name] = {'prompts': 0, 'segments': 0, 'avg_segments': 0}
        except Exception as e:
            print(f"Error processing {filename}: {e}")
            results[domain_name] = {'prompts': 0, 'segments': 0, 'avg_segments': 0}
    
    # Calculate totals
    total_prompts = sum(result['prompts'] for result in results.values())
    total_segments = sum(result['segments'] for result in results.values())
    total_avg = round(total_segments / total_prompts, 2) if total_prompts > 0 else 0
    
    # Generate LaTeX table
    latex_table = r"""\begin{table}[H]
\centering
\begin{tabular}{lccc}
\toprule
\textbf{Domain} & \textbf{\# Prompts} & \textbf{\# Segments} & \textbf{Avg. Seg./Prompt} \\
\midrule
"""
    
    # Add rows for each domain in the desired order
    domains_order = ['World Knowledge', 'Science', 'Mathematics', 'Reasoning']
    
    for domain in domains_order:
        data = results[domain]
        latex_table += f"{domain} & {data['prompts']} & {data['segments']} & {data['avg_segments']} \\\\\n"
    
    # Add total row
    latex_table += f"\\textbf{{Total}} & {total_prompts} & {total_segments} & {total_avg} \\\\\n"
    
    # Close the table
    latex_table += r"""\bottomrule
\end{tabular}
\caption{Dataset statistics across the four domains of BanglaFact.}
\label{tab:dataset-overview}
\end{table}"""
    
    return latex_table, results

# Run the code
print("Processing JSONL files in current directory...")
print("=" * 60)
latex_output, results_data = process_files()

print("\n" + "=" * 60)
print("FINAL LaTeX TABLE:")
print("=" * 60)
print(latex_output)

# Print summary for verification
print("\nSUMMARY STATISTICS:")
print("=" * 50)
for domain, data in results_data.items():
    print(f"{domain:20} | {data['prompts']:>6} prompts | {data['segments']:>6} segments | {data['avg_segments']:>5} avg segments/prompt")

total_prompts = sum(data['prompts'] for data in results_data.values())
total_segments = sum(data['segments'] for data in results_data.values())
print("=" * 50)
print(f"{'TOTAL':20} | {total_prompts:>6} prompts | {total_segments:>6} segments | {total_segments/total_prompts:.2f} avg segments/prompt")