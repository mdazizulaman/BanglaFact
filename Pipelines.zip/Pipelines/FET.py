import time
import os, json, re, csv, ast
from typing import List, Dict, Any, Optional, Tuple
from openai import OpenAI
import pandas as pd
from kaggle_secrets import UserSecretsClient
from openai import OpenAI

# =========================
# Auth & Client
# =========================
user_secrets = UserSecretsClient()
OPENROUTER_API_KEY = user_secrets.get_secret("OPENROUTER_API_KEY")
assert OPENROUTER_API_KEY, "❌ OpenRouter API key is missing. Please add it in Kaggle Secrets."

client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=OPENROUTER_API_KEY,
)

# Optional model alias registry
MODEL_REGISTRY = {
    "deepseek":      "deepseek/deepseek-chat-v3.1:free",
    "llama4":        "meta-llama/llama-4-maverick:free",
    "llama3.3_70b":  "meta-llama/llama-3.3-70b-instruct:free",
}
def _resolve_model_id(alias_or_id: str) -> str:
    return MODEL_REGISTRY.get(alias_or_id, alias_or_id)

# =========================
# Utils
# =========================
def parse_list_like(s, default=None):
    """
    Safely parse fields like "['a','b']" or "[True, False]" that arrive as strings.
    Returns default (or []) on failure.
    """
    if s is None:
        return default if default is not None else []
    if isinstance(s, list):
        return s
    if isinstance(s, str):
        s = s.strip()
        if s.lower() in {'nan', 'none', ''}:
            return default if default is not None else []
        try:
            val = ast.literal_eval(s)
            if isinstance(val, (list, tuple)):
                return list(val)
            return default if default is not None else []
        except Exception:
            return default if default is not None else []
    return default if default is not None else []

def coerce_bool_list(xs, n=None):
    """Turn entries into clean booleans; pad/trim to length n if given."""
    out = []
    for x in xs:
        if isinstance(x, bool):
            out.append(x)
        elif isinstance(x, (int, float)):
            out.append(bool(x))
        elif isinstance(x, str):
            t = x.strip().lower()
            if t in {'true', 't', '1', 'yes'}:   out.append(True)
            elif t in {'false', 'f', '0', 'no'}: out.append(False)
            else:                                out.append(False)
        else:
            out.append(False)
    if n is not None:
        out = (out[:n] + [False]*max(0, n-len(out)))
    return out

# =========================
# FET Prompt Builder
# =========================
# Single prompt file for ALL domains/methods
FET_PROMPT_PATH = "/kaggle/input/prompts-template-en/prompts/FET/FET Prompt.txt"

def _read_file(path: str) -> str:
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read().rstrip() + "\n"
    except FileNotFoundError:
        return f"[MISSING TEMPLATE at {path}]\n"

def build_eval_prompt(
    question: str,
    segments: list[str],
) -> str:
    base = _read_file(FET_PROMPT_PATH)
    print(f"[build_eval_prompt] Using template: {FET_PROMPT_PATH}")

    lines = [base]
    lines.append(f"Question: {question}")
    lines.append("Segments:")
    for i, seg in enumerate(segments, start=1):
        lines.append(f"{i}. {seg}")

    # Strict JSON spec for FET:
    # - incorrect_indices = segments that are NOT direct answers (FALSE)
    # - confidence = one float per segment in [0,1]
    lines.append(
        "\nReturn STRICT JSON only:\n"
        "{\n"
        '  "incorrect_indices": [ints from 1..N],\n'
        '  "confidence": [floats in 0..1, N items]\n'
        "}\n"
        "No extra text."
    )
    return "\n".join(lines)

# =========================
# Inference
# =========================
def gene(
    eval_prompt: str,
    *,
    model: str,
    site_url: str,
    site_title: str,
    max_tokens: int,
    temperature: float
) -> Tuple[str, list[dict]]:
    print(f"[gene] Calling model={model}")
    messages = [
        {"role": "system", "content": "You are a precise FET evaluator. Label segments as direct answers vs extra info only. Do not fact-check."},
        {"role": "user", "content": eval_prompt}
    ]
    completion = client.chat.completions.create(
        model=_resolve_model_id(model),
        messages=messages,
        temperature=temperature,
        max_tokens=max_tokens,
        extra_headers={"HTTP-Referer": site_url, "X-Title": site_title},
        extra_body={}
    )
    print("[gene] Received response from model")
    return completion.choices[0].message.content, messages

def _extract_json_block(text: str) -> dict:
    print("[extract_json] Parsing model output...")
    text = (text or "").strip()
    try:
        return json.loads(text)
    except Exception:
        m = re.search(r"\{[\s\S]*\}", text)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                pass
    return {}

def _normalize_output(obj: dict, n: int) -> Dict[str, Any]:
    # incorrect_indices: which segments are NOT direct answers
    inc = obj.get("incorrect_indices", []) or []
    conf = obj.get("confidence", []) or []

    picked = []
    for x in inc:
        try:
            xi = int(x)
            if 1 <= xi <= n:
                picked.append(xi)
        except Exception:
            continue

    # pred_raw: 1 = NOT direct (FALSE), 0 = direct (TRUE)  [raw model semantics]
    pred_raw = [0]*n
    for idx in picked:
        pred_raw[idx-1] = 1

    # Clip/parse confidence
    conf2 = []
    for c in conf[:n]:
        try:
            x = float(c)
            x = max(0.0, min(1.0, x))
        except Exception:
            x = 0.0
        conf2.append(x)
    conf2 += [0.0]*max(0, n-len(conf2))

    return {"pred_raw": pred_raw, "confidence": conf2}

# =========================
# Main Pipeline
# =========================
def run_pipeline_for_testset(
    *,
    jsonl_path: str,
    model_alias_or_id: str,
    site_url: str,
    site_title: str,
    max_tokens: int = 100,
    temperature: float = 0.2
) -> list[Dict[str, Any]]:

    rows: list[Dict[str, Any]] = []
    sample_count = 0
    segment_count = 0

    with open(jsonl_path, 'r', encoding='utf-8') as f:
        for line_idx, line in enumerate(f, start=1):
            if not line.strip():
                continue
            data = json.loads(line)

            sample_id = data.get('sample_id')
            print(f"[pipeline] Processing sample {sample_id} (line {line_idx})")

            domain    = data.get('domain', 'wk')  # echo only
            question  = data.get('prompts')
            segments  = parse_list_like(data.get('segmented_response', "[]"), default=[])

            # Load BOTH labels (entailment = gold FET, factual = echo only)
            gold_entail = coerce_bool_list(
                parse_list_like(data.get('entailment_label', "[]"), default=[]),
                n=len(segments)
            )
            gold_factual = coerce_bool_list(
                parse_list_like(data.get('factual_label', "[]"), default=[]),
                n=len(segments)
            )

            n = len(segments)
            if n == 0:
                print(f"[pipeline] Skipping sample {sample_id}: no segments")
                continue

            sample_count += 1
            segment_count += n

            eval_prompt = build_eval_prompt(question=question, segments=segments)

            # Measure inference time for one sample
            start_time = time.time()

            raw, _messages = gene(
                eval_prompt,
                model=model_alias_or_id,
                site_url=site_url,
                site_title=site_title,
                max_tokens=max_tokens,
                temperature=temperature
            )

            obj    = _extract_json_block(raw)
            parsed = _normalize_output(obj, n)

            end_time = time.time()
            elapsed_time = end_time - start_time
            for i in range(n):
                # parsed["pred_raw"][i] == 0 -> direct (TRUE)
                # parsed["pred_raw"][i] == 1 -> extra  (FALSE)
                predicted_FET = 1 if parsed["pred_raw"][i] == 0 else 0

                rows.append({
                    "sample_id": sample_id,
                    "domain": domain,
                    "prompt": question,
                    "segment_id": i + 1,

                    # FET outputs
                    "predicted_FET_label": predicted_FET,                 # TRUE=1, FALSE=0
                    "pred_confidence": float(parsed["confidence"][i]),

                    "gold_entailment_label": gold_entail[i] if i < len(gold_entail) else None,
                    "factual_label": gold_factual[i] if i < len(gold_factual) else None,

                    "inference_time": elapsed_time,   # <-- NEW
                    # Trace
                    "raw_model_output": raw,
                })

            print(f"[pipeline] Done with sample {sample_id}, added {n} rows")

    print("========== SUMMARY ==========")
    print(f"Total samples processed : {sample_count}")
    print(f"Total segments processed: {segment_count}")
    print("=============================")

    return rows

# =========================
# Save Helpers
# =========================
def save_rows_csv(rows: list[Dict[str, Any]], path: str):
    if not rows:
        with open(path, 'w', newline='', encoding='utf-8') as f:
            pass
        return
    fieldnames = list(rows[0].keys())
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow(r)

def save_rows_jsonl(rows: list[Dict[str, Any]], path: str):
    with open(path, 'w', encoding='utf-8') as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

# =========================
# CONFIG
# =========================
JSONL_PATH  = "/kaggle/input/test-data/test_set.jsonl"  # put your JSONL here
MODEL       = "deepseek"                            # or full "provider/model-id"
OUT_DIR     = "/kaggle/working/res"
SITE_URL    = "<YOUR_SITE_URL>"                         # optional: for OpenRouter rankings
SITE_TITLE  = "<YOUR_SITE_NAME>"

os.makedirs(OUT_DIR, exist_ok=True)

# =========================
# RUN
# =========================
rows = run_pipeline_for_testset(
    jsonl_path=JSONL_PATH,
    model_alias_or_id=MODEL,
    site_url=SITE_URL,
    site_title=SITE_TITLE,
    max_tokens=600,
    temperature=0.2
)

# =========================
# SAVE
# =========================
base_name = f"fet_outputs_{MODEL}"
csv_path   = os.path.join(OUT_DIR, f"{base_name}.csv")
jsonl_path = os.path.join(OUT_DIR, f"{base_name}.jsonl")

save_rows_csv(rows, csv_path)
save_rows_jsonl(rows, jsonl_path)

print(f"[save] Wrote {len(rows)} rows")
print(f"[save] CSV   -> {csv_path}")
print(f"[save] JSONL -> {jsonl_path}")

# Quick preview
pd.DataFrame(rows).head()
