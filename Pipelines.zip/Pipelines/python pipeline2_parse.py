import os
import json
import ast
import math
import re
from typing import List, Dict, Any, Optional, Tuple

import pandas as pd
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("pipeline2")

# ======================================================
# Utilities
# ======================================================

def parse_list_like(s, default=None):
    if s is None:
        return default if default is not None else []
    if isinstance(s, list):
        return s
    if isinstance(s, str):
        s = s.strip()
        if s.lower() in {"nan", "none", ""}:
            return default if default is not None else []
        try:
            val = ast.literal_eval(s)
            if isinstance(val, (list, tuple)):
                return list(val)
            return default if default is not None else []
        except Exception:
            return default if default is not None else []
    return default if default is not None else []


def coerce_bool_list(xs, n=None):
    out = []
    for x in xs:
        if isinstance(x, bool):
            out.append(x)
        elif isinstance(x, (int, float)):
            out.append(bool(x))
        elif isinstance(x, str):
            t = x.strip().lower()
            if t in {"true", "t", "1", "yes"}:
                out.append(True)
            elif t in {"false", "f", "0", "no"}:
                out.append(False)
            else:
                out.append(False)
        else:
            out.append(False)
    if n is not None:
        out = (out[:n] + [False] * max(0, n - len(out)))
    return out


def _slug(x: str) -> str:
    return re.sub(r"[^a-zA-Z0-9._-]+", "_", str(x)).strip("_").lower()


# ======================================================
# JSON extraction & normalization
# ======================================================

def _extract_json_block(text: str) -> dict:
    logger.info("[parse] Extracting JSON from raw_model_output...")
    text = (text or "").strip()
    if not text:
        return {}
    # Strict JSON first
    try:
        obj = json.loads(text)
        logger.info("[parse] Parsed strict JSON.")
        return obj
    except Exception:
        pass

    # Fallback: first {...} block
    m = re.search(r"\{[\s\S]*\}", text)
    if m:
        try:
            obj = json.loads(m.group(0))
            logger.info("[parse] Parsed JSON from first {...} block.")
            return obj
        except Exception:
            logger.warning("[parse] Failed to parse JSON from {...} block.")
            return {}
    logger.warning("[parse] No JSON found; returning empty object.")
    return {}


def _normalize_output(obj: dict, n: int) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """
    Normalize JSON from model:

    Expected fields:
      - "incorrect_indices": [1..N] (segments marked incorrect)
      - "confidence": either:
            * length N   → one per segment, OR
            * length K   → one per incorrect index

    Rules:
      - "incorrect_indices": [] → all segments TRUE
      - any "ALL_CORRECT"/"all_correct": true → all segments TRUE
      - otherwise: indices in incorrect_indices are FALSE, others TRUE

    For confidence:
      - if len == N, treat as per-segment
      - elif len == len(incorrect_indices), apply only to incorrect segments
      - else, fill sequentially for first min(N, len(...)), rest NaN
    """
    if not isinstance(obj, dict) or not obj:
        return None, "empty_or_non_dict"

    # 1) Detect ALL_CORRECT variants
    all_correct_flag = False

    # boolean flag
    if isinstance(obj.get("all_correct"), bool):
        all_correct_flag = obj["all_correct"]

    # textual ALL_CORRECT in any top-level value
    if not all_correct_flag:
        for v in obj.values():
            if isinstance(v, str) and v.strip().upper() == "ALL_CORRECT":
                all_correct_flag = True
                break

    inc_raw = obj.get("incorrect_indices", None)

    def _norm_conf(conf_raw, picked_indices):
        """Normalize confidence into length-N list."""  # <<< CHANGED
        conf_raw = conf_raw or []
        conf = [math.nan] * n

        def _clamp(x):
            try:
                v = float(x)
                if v < 0.0:
                    return 0.0
                if v > 1.0:
                    return 1.0
                return v
            except Exception:
                return math.nan

        if len(conf_raw) == n:
            # per-segment confidences
            for i in range(n):
                conf[i] = _clamp(conf_raw[i])
        elif picked_indices and len(conf_raw) == len(picked_indices):
            # per-incorrect-only confidences
            for k, idx in enumerate(picked_indices):
                if 1 <= idx <= n:
                    conf[idx - 1] = _clamp(conf_raw[k])
            # others remain NaN
        else:
            # fallback: sequential best-effort
            m = min(n, len(conf_raw))
            for i in range(m):
                conf[i] = _clamp(conf_raw[i])

        return conf

    # 2) CASE A: all correct (explicit or via empty incorrect_indices)
    if all_correct_flag or inc_raw == []:
        pred = [1] * n  # all TRUE
        conf_raw = obj.get("confidence", []) or []
        conf = _norm_conf(conf_raw, picked_indices=[])

        logger.info(
            f"[parse] normalized (ALL_CORRECT or empty incorrect_indices): "
            f"pred(len={len(pred)}), conf(len={len(conf)})"
        )
        return {"pred": pred, "confidence": conf}, None

    # 3) CASE B: need incorrect_indices
    if inc_raw is None:
        return None, "missing_incorrect_indices"

    if not isinstance(inc_raw, (list, tuple)):
        return None, "incorrect_indices_not_list"

    picked = []
    for x in inc_raw:
        try:
            xi = int(x)
        except Exception:
            return None, "incorrect_index_not_int"
        if not (1 <= xi <= n):
            return None, "incorrect_index_out_of_range"
        picked.append(xi)

    pred = [1] * n
    for idx in picked:
        pred[idx - 1] = 0

    conf_raw = obj.get("confidence", []) or []
    conf = _norm_conf(conf_raw, picked_indices=picked)

    logger.info(
        f"[parse] normalized: pred(len={len(pred)}), conf(len={len(conf)})"
    )
    return {"pred": pred, "confidence": conf}, None


# ======================================================
# PIPELINE 2: parse FELM raw outputs → per-segment rows
# ======================================================

def parse_felm_raw_file(
    raw_csv_path: str,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """
    Input: CSV from Pipeline 1 with columns like:
      - line_idx
      - sample_id
      - domain
      - method
      - model
      - question
      - segments
      - reference_links
      - reference_content
      - gold_labels
      - raw_model_output
      - inference_time

    Output:
      - parsed_rows: one row per segment
      - errors: per-sample parse errors
    """
    logger.info(f"[pipeline2] Loading raw CSV: {raw_csv_path}")
    df = pd.read_csv(raw_csv_path)

    parsed_rows: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []

    logger.info(f"[pipeline2] Total raw rows (samples): {len(df)}")

    # ---- compute expected total segments from raw CSV ----
    expected_segments = 0
    for idx, row in df.iterrows():
        try:
            segs_tmp = parse_list_like(row.get("segments", "[]"), default=[])
            expected_segments += len(segs_tmp)
        except Exception:
            # If we can't even parse here, treat as 0 for expectation
            pass

    logger.info(f"[pipeline2] Expected total segments from raw CSV: {expected_segments}")

    # Counters
    total_segments_output = 0
    samples_with_errors = 0

    for idx, row in df.iterrows():
        sample_id = row.get("sample_id")
        domain = row.get("domain", "wk")
        method = row.get("method", "raw")
        model = row.get("model", "")
        question = row.get("question", "")
        line_idx = row.get("line_idx", idx + 1)

        logger.info(f"\n[pipeline2] --- Sample {sample_id} (line_idx={line_idx}) ---")

        try:
            segments = parse_list_like(row.get("segments", "[]"), default=[])
            ref_links = parse_list_like(row.get("reference_links", "[]"), default=[])
            ref_docs = parse_list_like(row.get("reference_content", "[]"), default=[])
            gold_raw = parse_list_like(row.get("gold_labels", "[]"), default=[])
        except Exception as e:
            logger.error(f"[pipeline2] ERROR: parse_list_like failed for sample {sample_id}: {e}")
            errors.append({
                "line_idx": int(line_idx) if not pd.isna(line_idx) else idx + 1,
                "sample_id": sample_id,
                "domain": domain,
                "method": method,
                "model": model,
                "error_type": "input_parse_error_pipeline2",
                "exception": str(e),
            })
            samples_with_errors += 1
            continue

        n = len(segments)
        logger.info(
            f"[pipeline2] segments={n}, links={len(ref_links)}, docs={len(ref_docs)}"
        )

        if n == 0:
            logger.error(f"[pipeline2] ERROR: no segments for sample {sample_id}")
            errors.append({
                "line_idx": int(line_idx) if not pd.isna(line_idx) else idx + 1,
                "sample_id": sample_id,
                "domain": domain,
                "method": method,
                "model": model,
                "error_type": "no_segments_pipeline2",
            })
            samples_with_errors += 1
            continue

        gold = coerce_bool_list(gold_raw, n=n)

        raw_output = row.get("raw_model_output", "")
        if not isinstance(raw_output, str):
            raw_output = str(raw_output)

        obj = _extract_json_block(raw_output)
        parsed, parse_error_type = _normalize_output(obj, n)

        if parsed is None:
            logger.error(
                f"[pipeline2] ERROR: parse/normalize failure for sample "
                f"{sample_id} (reason={parse_error_type})"
            )
            errors.append({
                "line_idx": int(line_idx) if not pd.isna(line_idx) else idx + 1,
                "sample_id": sample_id,
                "domain": domain,
                "method": method,
                "model": model,
                "error_type": "parse_error_pipeline2",
                "parse_error_type": parse_error_type,
                "raw_model_output": raw_output,
            })
            samples_with_errors += 1
            continue

        inference_time = row.get("inference_time", None)

        for i in range(n):
            conf_i = parsed["confidence"][i]
            try:
                conf_val = float(conf_i) if isinstance(conf_i, (float, int)) else math.nan
            except Exception:
                conf_val = math.nan

            parsed_rows.append({
                "line_idx": int(line_idx) if not pd.isna(line_idx) else idx + 1,
                "sample_id": sample_id,
                "domain": domain,
                "method": method,
                "model": model,
                "prompt": question,
                "segment_id": i + 1,
                "segment_text": segments[i],
                "predicted_label": int(parsed["pred"][i]),
                "pred_confidence": conf_val,
                "gold_label": bool(gold[i]) if i < len(gold) else False,
                "inference_time": inference_time,
                "raw_model_output": raw_output,
            })

        total_segments_output += n
        logger.info(
            f"[pipeline2] ✓ Sample {sample_id} -> added {n} segment rows"
        )

    logger.info("\n========== PIPELINE 2 SUMMARY ==========")
    logger.info(f"Expected total segments from input : {expected_segments}")
    logger.info(f"Total per-segment rows produced    : {total_segments_output}")
    logger.info(f"Total errors collected             : {len(errors)}")
    logger.info(f"Samples with errors (skipped)      : {samples_with_errors}")
    logger.info("========================================\n")

    return parsed_rows, errors


# ======================================================
# Save helpers
# ======================================================

def save_rows_csv(rows: List[Dict[str, Any]], path: str):
    logger.info(f"[save] Writing CSV -> {path}")
    if not rows:
        with open(path, "w", newline="", encoding="utf-8") as f:
            pass
        return
    df = pd.DataFrame(rows)
    df.to_csv(path, index=False, encoding="utf-8-sig")


def save_rows_jsonl(rows: List[Dict[str, Any]], path: str):
    logger.info(f"[save] Writing JSONL -> {path}")
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


# ======================================================
# Batch runner: run over folder of felm_raw_*.csv
# ======================================================

def run_pipeline2_over_folder(
    raw_dir: str,
    out_dir: str,
):
    """
    raw_dir: folder with felm_raw_*.csv or felm_outputs_*.csv (Pipeline 1 outputs)
    out_dir: folder to write felm_parsed_*.csv / .jsonl and error log
    """
    os.makedirs(out_dir, exist_ok=True)
    all_errors: List[Dict[str, Any]] = []

    logger.info(f"[batch2] Scanning RAW_DIR={raw_dir}")
    logger.info(f"[batch2] RAW_DIR contents: {os.listdir(raw_dir)}")

    for fname in os.listdir(raw_dir):
        if not fname.endswith(".csv"):
            continue
        if not (fname.startswith("felm_raw_") or fname.startswith("felm_outputs_")):
            continue

        raw_csv_path = os.path.join(raw_dir, fname)
        logger.info(f"[batch2] Processing raw file: {raw_csv_path}")

        parsed_rows, errors = parse_felm_raw_file(raw_csv_path)
        all_errors.extend(errors)

        base_name = fname.replace("felm_raw_", "felm_parsed_")
        base_name = base_name.replace("felm_outputs_", "felm_parsed_")
        out_csv = os.path.join(out_dir, base_name)
        out_json = os.path.join(out_dir, base_name.replace(".csv", ".jsonl"))

        save_rows_csv(parsed_rows, out_csv)
        save_rows_jsonl(parsed_rows, out_json)

        logger.info(f"[batch2] Saved parsed outputs -> {out_csv}, {out_json}")

    err_path = os.path.join(out_dir, "pipeline2_errors.jsonl")
    logger.info(f"[errors] Writing {len(all_errors)} errors -> {err_path}")
    with open(err_path, "w", encoding="utf-8") as ef:
        for e in all_errors:
            ef.write(json.dumps(e, ensure_ascii=False) + "\n")

    logger.info("[batch2] Pipeline 2 over folder complete.")


# ======================================================
# MAIN
# ======================================================

if __name__ == "__main__":
    RAW_DIR = r"C:/Users/azizu\Downloads/FELM REPORT WRITING/results"
    OUT_DIR = r"C:/Users/azizu\Downloads/FELM REPORT WRITING/results/parsed_out"

    run_pipeline2_over_folder(RAW_DIR, OUT_DIR)
