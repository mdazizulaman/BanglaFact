import time
import os, json, re, csv, ast
from typing import List, Dict, Any, Optional, Tuple
from openai import OpenAI
import pandas as pd
from kaggle_secrets import UserSecretsClient
from tenacity import retry, stop_after_attempt, wait_random_exponential, before_sleep_log
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("retry")

print("[setup] Initializing OpenRouter client and secrets...")
user_secrets = UserSecretsClient()
OPENROUTER_API_KEY = user_secrets.get_secret("OPENROUTER_API_KEY")
assert OPENROUTER_API_KEY, "OpenRouter API key is missing. Please add it in Kaggle Secrets."

client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=OPENROUTER_API_KEY,
)

MODEL_REGISTRY = {
    "llama-3.1-8b-instruct": "meta-llama/llama-3.1-8b-instruct",
    "qwen-2.5-7b-instruct":  "qwen/qwen-2.5-7b-instruct",
    "gemma-3-12b-it":        "google/gemma-3-12b-it",
    "gpt-3.5-turbo":         "openai/gpt-3.5-turbo",
    "mistral-nemo":          "mistralai/mistral-nemo",
    "gpt-4o-mini":           "openai/gpt-4o-mini-2024-07-18",
    "mistral-7b-instruct":   "mistralai/mistral-7b-instruct",
}

def _resolve_model_id(alias_or_id: str) -> str:
    mid = MODEL_REGISTRY.get(alias_or_id, alias_or_id)
    print(f"[setup] Using model id: {mid}")
    return mid

def validate_model_output(output_text: str, num_segments: int) -> Tuple[bool, str]:
    """
    Validate model output before attempting JSON parsing.
    Returns (is_valid, error_type) tuple.

    Assumptions:
    - Segments are numbered 1..num_segments in the prompt.
    - incorrect_indices must be in [1, num_segments].
    - confidence must have exactly num_segments values.
    """

    if not output_text or output_text.strip() == "":
        return False, "empty_output"

    if '"incorrect_indices"' not in output_text or '"confidence"' not in output_text:
        return False, "missing_required_fields"

    incorrect_pattern = r'"incorrect_indices"\s*:\s*\[([^\]]*)\]'
    incorrect_match = re.search(incorrect_pattern, output_text)

    if not incorrect_match:
        malformed_patterns = [
            r'"incorrect_indices"\s*:\s*\[?',
            r'"incorrect_indices"\s*:\s*$',
            r'"incorrect_indices"\s*$',
        ]
        for pattern in malformed_patterns:
            if re.search(pattern, output_text, re.MULTILINE):
                return False, "malformed_incorrect_indices"
        return False, "missing_incorrect_indices"

    indices_content = incorrect_match.group(1).strip()

    if indices_content == "":
        pass
    else:
        try:
            indices = [int(x.strip()) for x in indices_content.split(',') if x.strip()]
            for idx in indices:
                if idx < 1 or idx > num_segments:
                    return False, "index_out_of_range"
        except ValueError:
            return False, "malformed_indices_content"

    confidence_pattern = r'"confidence"\s*:\s*\[([^\]]*)\]'
    confidence_match = re.search(confidence_pattern, output_text)

    if not confidence_match:
        malformed_confidence_patterns = [
            r'"confidence"\s*:\s*\[?',
            r'"confidence"\s*:\s*$',
            r'"confidence"\s*$',
        ]
        for pattern in malformed_confidence_patterns:
            if re.search(pattern, output_text, re.MULTILINE):
                return False, "malformed_confidence"
        return False, "missing_confidence"

    confidence_content = confidence_match.group(1).strip()

    if confidence_content == "":
        return False, "empty_confidence_array"

    try:
        confidence_values = [x.strip() for x in confidence_content.split(',') if x.strip()]
        if len(confidence_values) != num_segments:
            return False, "confidence_count_mismatch"

        for val in confidence_values:
            float(val)
    except ValueError:
        return False, "malformed_confidence_values"

    return True, "valid"

def parse_json_output(raw_output: str) -> Dict[str, Any]:
    """
    Parse JSON output with error handling.
    (Used in Pipeline 2, not here yet.)
    """
    try:
        json_match = re.search(r'\{.*\}', raw_output, re.DOTALL)
        if json_match:
            json_str = json_match.group(0)
            return json.loads(json_str)
        else:
            return json.loads(raw_output)
    except json.JSONDecodeError as e:
        raise e

def parse_list_like(s, default=None):
    if default is None:
        default = []

    if s is None:
        return default

    if isinstance(s, list):
        return s

    if isinstance(s, str):
        s = s.strip()
        if s.lower() in {"nan", "none", ""}:
            return default

        try:
            val = ast.literal_eval(s)
            if isinstance(val, (list, tuple)):
                return list(val)
            return default
        except Exception:
            pass

        if s.startswith("[") and s.endswith("]"):
            inner = s[1:-1].strip()
            parts = re.split(r"',\s*'", inner)

            cleaned = []
            for p in parts:
                p = p.strip()

                if p.startswith("'"):
                    p = p[1:]
                if p.endswith("'"):
                    p = p[:-1]

                cleaned.append(p)

            return cleaned

        return default

    return default

def _slug(x: str) -> str:
    return re.sub(r"[^a-zA-Z0-9._-]+", "_", str(x)).strip("_").lower()

def _read_file(path: str) -> str:
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read().rstrip() + "\n"
    except FileNotFoundError:
        return f"[MISSING TEMPLATE at {path}]\n"

PROMPTS_ROOT = "/kaggle/input/prompts-template-en/prompt_5/prompt/zero shot/segment"

TEMPLATE_PATHS = {
    ('math','raw'):         os.path.join(PROMPTS_ROOT, "math", "raw.txt"),
    ('math','cot'):         os.path.join(PROMPTS_ROOT, "math", "cot.txt"),

    ('reasoning','raw'):    os.path.join(PROMPTS_ROOT, "reasoning", "raw.txt"),
    ('reasoning','cot'):    os.path.join(PROMPTS_ROOT, "reasoning", "cot.txt"),

    ('science','raw'):      os.path.join(PROMPTS_ROOT, "sci", "prompt_sci_raw.txt"),
    ('science','cot'):      os.path.join(PROMPTS_ROOT, "sci", "prompt_sci_cot.txt"),
    ('science','link'):     os.path.join(PROMPTS_ROOT, "sci", "prompt_sci_ret_link.txt"),
    ('science','content'):  os.path.join(PROMPTS_ROOT, "sci", "prompt_sci_ret_content.txt"),

    ('wk','raw'):           os.path.join(PROMPTS_ROOT, "wk", "prompt_wk_raw.txt"),
    ('wk','cot'):           os.path.join(PROMPTS_ROOT, "wk", "prompt_wk_cot.txt"),
    ('wk','link'):          os.path.join(PROMPTS_ROOT, "wk", "prompt_wk_ret_link.txt"),
    ('wk','content'):       os.path.join(PROMPTS_ROOT, "wk", "prompt_wk_ret_content.txt"),

    ('writing_rec','raw'):      os.path.join(PROMPTS_ROOT, "wk", "prompt_wk_raw.txt"),
    ('writing_rec','cot'):      os.path.join(PROMPTS_ROOT, "wk", "prompt_wk_cot.txt"),
    ('writing_rec','link'):     os.path.join(PROMPTS_ROOT, "wk", "prompt_wk_ret_link.txt"),
    ('writing_rec','content'):  os.path.join(PROMPTS_ROOT, "wk", "prompt_wk_ret_content.txt"),
}

def build_eval_prompt(
    dataset: str,
    method: str,
    question: str,
    segments: List[str],
    ref_links: Optional[List[str]] = None,
    ref_docs: Optional[List[str]] = None,
) -> str:
    tpl_path = TEMPLATE_PATHS.get((dataset, method)) or TEMPLATE_PATHS.get((dataset, 'raw'))
    print(f"[prompt] Using template: {tpl_path}")
    base = _read_file(tpl_path)

    lines = [base]
    lines.append(f"Question: {question}")
    lines.append("Segments:")
    for i, seg in enumerate(segments, start=1):
        lines.append(f"{i}. {seg}")

    if method == 'link' and ref_links:
        lines.append("\nReference links:")
        lines.extend([str(x) for x in ref_links])

    if method == 'content' and ref_docs:
        lines.append("\nReference doc:")
        lines.extend([str(x) for x in ref_docs])

    n = len(segments)
    lines.append("")
    lines.append("SYSTEM CONSTRAINTS (DO NOT IGNORE):")
    lines.append(f"- In THIS question, the number of segments is N = {n}.")
    lines.append(f"- You MUST output exactly N={n} float values in the \"confidence\" array.")
    lines.append(f"- The \"confidence\" array MUST have length {n}, with one value per segment.")
    lines.append("- Every value in \"incorrect_indices\" MUST be an integer between 1 and N (inclusive).")
    lines.append("- Do NOT invent extra segments or indices.")
    lines.append("- Do NOT output anything except the JSON object.")

    prompt = "\n".join(lines)
    print(
        f"[prompt] Built prompt with {len(segments)} segments; "
        f"links={len(ref_links) if ref_links else 0}, docs={len(ref_docs) if ref_docs else 0}"
    )
    return prompt

@retry(
    wait=wait_random_exponential(min=8, max=60),
    stop=stop_after_attempt(6),
    before_sleep=before_sleep_log(logger, logging.WARNING),
    reraise=True
)
def gene(
    eval_prompt: str,
    dataname: str,
    model: str,
    method: str,
    *,
    site_url: str,
    site_title: str,
    max_tokens: int,
    temperature: float
) -> Tuple[str, List[Dict[str, Any]]]:
    print(
        f"[gene] Calling model={model}, method={method}, domain={dataname}, "
        f"temp={temperature}, max_tokens={max_tokens}"
    )
    messages = [
        {"role": "system", "content": "You are a careful factuality evaluator."},
        {"role": "user", "content": eval_prompt}
    ]
    completion = client.chat.completions.create(
        model=_resolve_model_id(model),
        messages=messages,
        temperature=temperature,
        max_tokens=max_tokens,
        extra_headers={"HTTP-Referer": site_url, "X-Title": site_title},
        extra_body={}
    )
    print("[gene] Response received.")
    return completion.choices[0].message.content, messages

def run_pipeline1_for_testset(
    *,
    jsonl_path: str,
    model_alias_or_id: str,
    method: str,
    site_url: str,
    site_title: str,
    max_tokens: int = 256,
    temperature: float = 0.0,
    skip_if_missing_refs: bool = True,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:

    rows: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []
    sample_count = 0

    print(f"[pipeline1] Starting pass for method={method} on file={jsonl_path}")

    pipeline_start = time.time()
    with open(jsonl_path, 'r', encoding='utf-8') as f_count:
        total_samples = sum(1 for line in f_count if line.strip())
    print(f"[pipeline1] Total non-empty samples in file: {total_samples}")

    with open(jsonl_path, 'r', encoding='utf-8') as f:
        for line_idx, line in enumerate(f, start=1):
            if not line.strip():
                continue

            try:
                data = json.loads(line)
            except Exception as e:
                print(f"[pipeline1] ERROR: JSON decode failed at line {line_idx}: {e}")
                errors.append({
                    "line_idx": line_idx,
                    "sample_id": None,
                    "domain": None,
                    "method": method,
                    "error_type": "json_decode_error",
                    "exception": str(e),
                    "raw_line": line[:500],
                })
                continue

            sample_id = data.get('sample_id')
            domain    = data.get('domain', 'wk')
            question  = data.get('prompts')

            if sample_count == 0:
                print(f"[pipeline1] First sample loaded (line {line_idx}):")
                print(json.dumps(data, indent=2)[:1000])

            print(f"\n[pipeline1] --- Sample {sample_id} (line {line_idx}) ---")

            try:
                segments  = parse_list_like(data.get('segmented_response', "[]"), default=[])
                ref_links = parse_list_like(data.get('reference', None), default=[])
                if isinstance(ref_links, str):
                    ref_links = [ref_links] if ref_links else []
                ref_docs  = parse_list_like(data.get('reference_content', "[]"), default=[])
                gold      = parse_list_like(data.get('factual_label', "[]"), default=[])
            except Exception as e:
                print(f"[pipeline1] ERROR: input parse failure for sample {sample_id}: {e}")
                errors.append({
                    "line_idx": line_idx,
                    "sample_id": sample_id,
                    "domain": domain,
                    "method": method,
                    "error_type": "input_parse_error",
                    "exception": str(e),
                })
                continue

            n = len(segments)
            print(
                f"[pipeline1] domain={domain}, segments={n}, "
                f"links={len(ref_links)}, docs={len(ref_docs)}"
            )

            if n == 0:
                print(f"[pipeline1] ERROR: no segments; logging and skipping sample {sample_id}")
                errors.append({
                    "line_idx": line_idx,
                    "sample_id": sample_id,
                    "domain": domain,
                    "method": method,
                    "error_type": "no_segments",
                })
                continue

            if skip_if_missing_refs and method == 'link' and not ref_links:
                print(f"[pipeline1] ERROR: method=link but no reference links; logging error for sample {sample_id}")
                errors.append({
                    "line_idx": line_idx,
                    "sample_id": sample_id,
                    "domain": domain,
                    "method": method,
                    "error_type": "missing_reference_links",
                })
                continue

            if skip_if_missing_refs and method == 'content' and not ref_docs:
                print(f"[pipeline1] ERROR: method=content but no reference content; logging error for sample {sample_id}")
                errors.append({
                    "line_idx": line_idx,
                    "sample_id": sample_id,
                    "domain": domain,
                    "method": method,
                    "error_type": "missing_reference_content",
                })
                continue

            sample_count += 1
            start_time = time.time()

            eval_prompt = build_eval_prompt(
                dataset=domain,
                method=method,
                question=question,
                segments=segments,
                ref_links=ref_links if method == 'link' else None,
                ref_docs=ref_docs if method == 'content' else None
            )

            raw = None
            _messages = None
            max_attempts = 8
            retry_attempts = 0
            retry_details: List[Dict[str, Any]] = []

            try:
                for attempt in range(1, max_attempts + 1):
                    raw, _messages = gene(
                        eval_prompt, domain, model_alias_or_id, method,
                        site_url=site_url, site_title=site_title,
                        max_tokens=max_tokens, temperature=temperature
                    )

                    if not raw or not raw.strip():
                        retry_details.append({
                            "attempt": attempt,
                            "error_type": "empty_output",
                            "raw_output": None,
                            "validation_error": "Empty model output",
                            "num_segments": n,
                        })
                        print(f"[pipeline1] Empty output attempt {attempt}/{max_attempts} -> retrying...")
                        time.sleep(0.05)
                        continue

                    is_valid, error_type = validate_model_output(raw, n)
                    if not is_valid:
                        retry_details.append({
                            "attempt": attempt,
                            "error_type": f"validation_error: {error_type}",
                            "raw_output": raw[:500] if raw else None,
                            "validation_error": error_type,
                            "num_segments": n,
                        })
                        print(f"[pipeline1] Invalid output structure attempt {attempt}/{max_attempts} - {error_type} -> retrying...")
                        time.sleep(0.05)
                        continue

                    retry_attempts = attempt - 1
                    break

                elapsed_time = time.time() - start_time

                if not raw or not raw.strip():
                    print(
                        f"[pipeline1] ERROR: empty model output after {max_attempts} attempts "
                        f"for sample {sample_id}"
                    )
                    errors.append({
                        "line_idx": line_idx,
                        "sample_id": sample_id,
                        "domain": domain,
                        "method": method,
                        "error_type": "empty_model_output",
                        "inference_time": elapsed_time,
                        "retry_attempts": max_attempts,
                        "retry_details": retry_details,
                        "num_segments": n,
                    })
                    continue

                is_valid, error_type = validate_model_output(raw, n)
                if not is_valid:
                    print(
                        f"[pipeline1] ERROR: invalid model output after {max_attempts} attempts "
                        f"for sample {sample_id}: {error_type}"
                    )
                    errors.append({
                        "line_idx": line_idx,
                        "sample_id": sample_id,
                        "domain": domain,
                        "method": method,
                        "error_type": f"invalid_output_structure: {error_type}",
                        "inference_time": elapsed_time,
                        "raw_model_output": raw[:1000] if raw else None,
                        "retry_attempts": max_attempts,
                        "retry_details": retry_details,
                        "num_segments": n,
                    })
                    continue

            except Exception as e:
                elapsed_time = time.time() - start_time
                print(f"[pipeline1] ERROR: exception during model call for sample {sample_id}: {e}")
                errors.append({
                    "line_idx": line_idx,
                    "sample_id": sample_id,
                    "domain": domain,
                    "method": method,
                    "error_type": "model_exception",
                    "exception": str(e),
                    "inference_time": elapsed_time,
                    "retry_attempts": retry_attempts,
                    "retry_details": retry_details,
                    "num_segments": n,
                })
                continue

            print(f"[pipeline1] Inference time: {elapsed_time:.2f}s")
            print(f"[pipeline1] Retry attempts: {retry_attempts}")

            rows.append({
                "line_idx": line_idx,
                "sample_id": sample_id,
                "domain": domain,
                "method": method,
                "model": model_alias_or_id,
                "question": question,
                "segments": segments,
                "reference_links": ref_links,
                "reference_content": ref_docs,
                "gold_labels": gold,
                "raw_model_output": raw,
                "inference_time": elapsed_time,
                "retry_attempts": retry_attempts,
                "retry_details": retry_details,
                "final_attempt_successful": True,
            })

            print(f"[pipeline1] Sample {sample_id} -> raw output saved (after {retry_attempts} retries)")

            overall_elapsed = time.time() - pipeline_start
            avg_per_sample = overall_elapsed / sample_count if sample_count > 0 else 0.0
            est_total = avg_per_sample * total_samples if avg_per_sample > 0 else 0.0
            est_remaining = max(est_total - overall_elapsed, 0.0)
            progress_pct = (sample_count / total_samples * 100.0) if total_samples > 0 else 0.0

            print(
                f"[time] method={method} progress: "
                f"{sample_count}/{total_samples} ({progress_pct:.1f}%) | "
                f"elapsed={overall_elapsed/60:.2f} min | "
                f"ETA_total={est_total/60:.2f} min | "
                f"ETA_remaining={est_remaining/60:.2f} min"
            )

    print("\n========== PIPELINE 1 SUMMARY ==========")
    print(f"Total valid samples processed : {sample_count}")
    print(f"Total raw rows collected      : {len(rows)}")
    print(f"Total errors collected        : {len(errors)}")

    if rows:
        total_retries = sum(row.get('retry_attempts', 0) for row in rows)
        avg_retries = total_retries / len(rows)
        print(f"Total retry attempts         : {total_retries}")
        print(f"Average retries per sample   : {avg_retries:.2f}")

    total_elapsed_pipeline = time.time() - pipeline_start
    print(f"[time] Method {method} finished in {total_elapsed_pipeline/60:.2f} minutes ({total_elapsed_pipeline:.1f} seconds)")
    print("========================================\n")

    return rows, errors

def save_rows_csv(rows: List[Dict[str, Any]], path: str):
    print(f"[save] Writing CSV -> {path}")
    if not rows:
        with open(path, 'w', newline='', encoding='utf-8') as f:
            pass
        return
    df = pd.DataFrame(rows)
    df.to_csv(path, index=False, encoding="utf-8-sig")

def save_rows_jsonl(rows: List[Dict[str, Any]], path: str):
    print(f"[save] Writing JSONL -> {path}")
    with open(path, 'w', encoding='utf-8') as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

def run_all_methods_domainwise_pipeline1(
    *,
    jsonl_path: str,
    model_alias_or_id: str,
    methods: List[str],
    out_dir: str,
    site_url: str,
    site_title: str,
    max_tokens: int = 256,
    temperature: float = 0.0,
    skip_if_missing_refs: bool = True,
) -> Dict[str, Dict[str, Dict[str, str]]]:
    """
    PIPELINE 1:
    - Runs generation for each method
    - Saves outputs split by DOMAIN+METHOD
    - Writes a single error list file per model run: error_list.jsonl
    Returns {method: {domain: {"csv": path, "jsonl": path}}}
    """
    print(f"[batch1] Running methods={methods} into out_dir={out_dir}")
    os.makedirs(out_dir, exist_ok=True)
    outputs: Dict[str, Dict[str, Dict[str, str]]] = {}
    all_errors: List[Dict[str, Any]] = []

    for method in methods:
        print("\n==============================")
        print(f" PIPELINE 1 - Running method: {method}")
        print("==============================\n")

        rows, errors = run_pipeline1_for_testset(
            jsonl_path=jsonl_path,
            model_alias_or_id=model_alias_or_id,
            method=method,
            site_url=site_url,
            site_title=site_title,
            max_tokens=max_tokens,
            temperature=temperature,
            skip_if_missing_refs=skip_if_missing_refs,
        )
        all_errors.extend(errors)

        if not rows:
            print(f"[save] No rows for method={method}, skipping saves.")
            continue

        df = pd.DataFrame(rows)
        outputs[method] = {}

        for domain, ddf in df.groupby("domain"):
            dom = _slug(domain)
            mdl = _slug(model_alias_or_id)
            base_name = f"felm_raw_{mdl}_{dom}_{method}"

            csv_path   = os.path.join(out_dir, f"{base_name}.csv")
            json_path  = os.path.join(out_dir, f"{base_name}.jsonl")

            print(f"[save] ({domain} | {method}) rows={len(ddf)}")
            ddf.to_csv(csv_path, index=False, encoding="utf-8-sig")
            print(f"[save] CSV   -> {csv_path}")

            with open(json_path, "w", encoding="utf-8") as f:
                for _, row in ddf.iterrows():
                    f.write(json.dumps(row.to_dict(), ensure_ascii=False) + "\n")
            print(f"[save] JSONL -> {json_path}")

            outputs[method][domain] = {"csv": csv_path, "jsonl": json_path}

    err_path = os.path.join(out_dir, "error_list.jsonl")
    print(f"\n[errors] Writing {len(all_errors)} errors -> {err_path}")
    with open(err_path, "w", encoding="utf-8") as ef:
        for e in all_errors:
            ef.write(json.dumps(e, ensure_ascii=False) + "\n")

    print("[batch1] Done.")
    return outputs

if __name__ == "__main__":
    JSONL_PATH  = "/kaggle/input/test-data/wk_sci_full.jsonl"

    MODELS = [
         "mistral-nemo",
         "mistral-7b-instruct",
         "llama-3.1-8b-instruct",
         "qwen-2.5-7b-instruct",
         "gemma-3-12b-it",
         "gpt-3.5-turbo",
         "gpt-4o-mini",
    ]

    OUT_DIR     = "/kaggle/working/res_pipeline1"
    SITE_URL    = "<YOUR_SITE_URL>"
    SITE_TITLE  = "<YOUR_SITE_NAME>"

    METHODS_TO_RUN  = ["raw", "cot", "link", "content"]
    SKIP_EMPTY_REFS = True

    print("=" * 60)
    print("[main] PIPELINE 1 CONFIGURATION")
    print("=" * 60)
    print(f"Input file  : {JSONL_PATH}")
    print(f"Models      : {MODELS}")
    print(f"Output dir  : {OUT_DIR}")
    print(f"Methods     : {METHODS_TO_RUN}")
    print(f"Skip refs   : {SKIP_EMPTY_REFS}")
    print("=" * 60)

    if not os.path.exists(JSONL_PATH):
        raise FileNotFoundError(f"Input file not found: {JSONL_PATH}")
    with open(JSONL_PATH, 'r', encoding='utf-8') as f:
        line_count = sum(1 for _ in f)
        print(f"Input file exists with {line_count} lines")

    print("\n[main] PIPELINE 1: Starting domain-wise run for MULTIPLE MODELS...\n")

    all_outputs = {}

    for MODEL in MODELS:
        print("\n" + "=" * 60)
        print(f"[main] PIPELINE 1 - Running model: {MODEL}")
        print("=" * 60)

        out_dir_model = os.path.join(OUT_DIR, _slug(MODEL))
        os.makedirs(out_dir_model, exist_ok=True)

        outputs = run_all_methods_domainwise_pipeline1(
            jsonl_path=JSONL_PATH,
            model_alias_or_id=MODEL,
            methods=METHODS_TO_RUN,
            out_dir=out_dir_model,
            site_url=SITE_URL,
            site_title=SITE_TITLE,
            max_tokens=256,
            temperature=0.0,
            skip_if_missing_refs=SKIP_EMPTY_REFS,
        )
        all_outputs[MODEL] = outputs

        for method, dom_map in outputs.items():
            for domain, paths in dom_map.items():
                print(f"\n[preview] {domain} | {method} | model={MODEL} -> {paths['csv']}")
                try:
                    df_preview = pd.read_csv(paths["csv"])
                    print(f"Rows: {len(df_preview)}")
                    print(df_preview.head(3))
                except Exception as e:
                    print(f"[preview] Could not preview {paths['csv']}: {e}")

        error_file = os.path.join(out_dir_model, "error_list.jsonl")
        if os.path.exists(error_file):
            print(f"\n[main] PIPELINE 1 - Checking errors in {error_file}")
            with open(error_file, 'r', encoding='utf-8') as ef:
                errs = [json.loads(line) for line in ef]
                print(f"Total errors logged: {len(errs)}")
                if errs:
                    print("\nFirst 3 errors:")
                    for i, err in enumerate(errs[:3], 1):
                        print(f"{i}. {err}")

    print("\n" + "=" * 60)
    print("[main] PIPELINE 1 EXECUTION COMPLETE (ALL MODELS)")
    print("=" * 60)

from kaggle import api

api.dataset_create_new(
    folder="/kaggle/working/res_pipeline1",
    dir_mode="zip",
    public=False,
    convert_to_csv=False,
    title="felm_pipeline1_auto_backup",
    slug="felm-pipeline1-auto-backup"
)